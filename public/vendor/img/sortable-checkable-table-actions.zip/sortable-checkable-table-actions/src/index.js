import  "./assets/scss/main.scss";
import { TableActions } from "./table-actions";

export default TableActions;
